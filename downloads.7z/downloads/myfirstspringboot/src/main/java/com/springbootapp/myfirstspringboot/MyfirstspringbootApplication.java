package com.springbootapp.myfirstspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstspringbootApplication.class, args);
	}

}
