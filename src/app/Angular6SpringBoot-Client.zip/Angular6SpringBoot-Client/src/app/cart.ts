import { Coupon } from "./coupon";

export class Cart {
    id:number;

    uname=localStorage.getItem('ankit');
    coupon:any;
}