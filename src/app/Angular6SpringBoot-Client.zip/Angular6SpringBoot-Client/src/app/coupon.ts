export class Coupon {
    id:number;
    name: string;
    category: string;
    price: number;
    description: string;
    imgurl:string;
}
